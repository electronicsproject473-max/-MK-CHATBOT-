import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  app.use(express.json());

  const PORT = 3000;

  // Lazy initialize Gemini client to avoid crashes if the key isn't provided at startup
  let aiClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY environment variable is missing. Please set it in Settings > Secrets.");
      }
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return aiClient;
  }

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Chat completion endpoint proxying Google Gemini API
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, systemInstruction, isPremium } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages payload must be a non-empty array." });
      }

      const client = getGeminiClient();

      // Format clean message items
      const contents = messages.map((m: any) => ({
        role: m.role === "assistant" || m.role === "model" ? "model" : "user",
        parts: [{ text: m.content || "" }],
      }));

      // Establish configuration options
      const config: any = {};
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }

      // If the user has upgraded to premium, grant Google Search Grounding
      if (isPremium) {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config,
      });

      const text = response.text || "No response received from model.";
      const searchChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const searchQueries = response.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

      res.json({
        text,
        groundingChunks: searchChunks
          .map((chunk: any) => {
            const web = chunk.web || chunk.maps;
            if (web) {
              return {
                title: web.title || "Web Reference",
                uri: web.uri || "#"
              };
            }
            return null;
          })
          .filter(Boolean),
        searchQueries,
      });

    } catch (err: any) {
      console.error("Gemini API Error in backend:", err.message || err);
      res.status(500).json({
        error: err.message || "An error occurred with the AI model pipeline.",
      });
    }
  });

  // Bind Vite Development Middleware or Serve Compiled Static Assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express dev-server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
