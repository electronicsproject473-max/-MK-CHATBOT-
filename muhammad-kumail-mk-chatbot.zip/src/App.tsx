import { useState, useEffect } from "react";
import { Cpu, Loader2, Sparkles, AlertTriangle } from "lucide-react";
import {
  subscribeToAuth,
  handleGoogleSignIn,
  handleSignOut,
  fetchUserProfile,
  createUserProfile,
  updateUserProfile,
  fetchChatSessions,
  createChatSession,
  deleteChatSession,
  updateChatSessionTitle,
  fetchChatMessages,
  addChatMessage,
  isFirebaseEnabled,
} from "./firebase";
import { ChatSession, ChatMessage, UserProfile } from "./types";
import Sidebar from "./components/Sidebar";
import ChatPlayground from "./components/ChatPlayground";
import PricingModal from "./components/PricingModal";
import LoginScreen from "./components/LoginScreen";

export default function App() {
  const [user, setUser] = useState<{ uid: string; email: string; displayName: string } | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  // Open overlays & panels states
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sysError, setSysError] = useState<string | null>(null);

  // 1. Subscribe to Authentication changes
  useEffect(() => {
    const unsubscribe = subscribeToAuth(async (firebaseUser) => {
      try {
        if (firebaseUser) {
          const userData = {
            uid: firebaseUser.uid,
            email: firebaseUser.email || "electronicsproject473@gmail.com",
            displayName: firebaseUser.displayName || "User",
          };
          setUser(userData);
          await handleBootstrappedUser(userData.uid, userData.email);
        } else {
          // If in local simulation mode (Firebase is placebo), look for pre-cached logins
          const cached = localStorage.getItem("mk_chat_cached_user");
          if (cached && !isFirebaseEnabled) {
            const userData = JSON.parse(cached);
            setUser(userData);
            await handleBootstrappedUser(userData.uid, userData.email);
          } else {
            setUser(null);
            setProfile(null);
            setSessions([]);
            setCurrentSessionId(null);
            setMessages([]);
          }
        }
      } catch (err: any) {
        console.error("Auth status sync failed:", err);
        setSysError(err.message || "Unable to sync with Firestore authentication gateway.");
      } finally {
        setIsAuthLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Ensure user profiles and lists are loaded
  async function handleBootstrappedUser(uid: string, email: string) {
    try {
      let isNewProfile = false;
      let userProfile = await fetchUserProfile(uid);
      if (!userProfile) {
        userProfile = await createUserProfile(uid, email);
        isNewProfile = true;
      }
      setProfile(userProfile);

      // Load conversation logs
      const chatSessions = await fetchChatSessions(uid);
      setSessions(chatSessions);

      if (chatSessions.length > 0) {
        setCurrentSessionId(chatSessions[0].id);
      } else if (isNewProfile) {
        // Automatically make a welcoming dialogue session
        const welcome = await createChatSession(uid, "Welcome Chat ✨");
        setSessions([welcome]);
        setCurrentSessionId(welcome.id);

        // Populate a friendly starter prompt
        await addChatMessage(
          welcome.id,
          "model",
          "Hello Muhammad Kumail! Welcome to your customizable premium chatbot workspace.\n\nI am powered by the Google Gemini API. As a standard user, you can prompt me for code samples, simple reasoning, or summaries.\n\n👑 If you choose to **Upgrade to Premium**, I will gain **Google Search Grounding**, allowing me to look up real-time news, scores, weather, and reference citations immediately!",
          uid
        );
      }
    } catch (err: any) {
      console.error("Failed to bootstrap user configs:", err);
      // Fallback state
      setSessions([]);
    }
  }

  // 2. Fetch messages whenever the active session workspace target transitions
  useEffect(() => {
    if (!currentSessionId) {
      setMessages([]);
      return;
    }

    async function loadMessages() {
      try {
        const msgs = await fetchChatMessages(currentSessionId!);
        setMessages(msgs);
      } catch (err: any) {
        console.error("Failed to load message stack:", err);
      }
    }

    loadMessages();
  }, [currentSessionId]);

  // Auth procedures
  const handleLoginSuccess = async (userData: { uid: string; email: string; displayName: string }) => {
    if (!isFirebaseEnabled) {
      localStorage.setItem("mk_chat_cached_user", JSON.stringify(userData));
    }
    setUser(userData);
    setIsAuthLoading(true);
    await handleBootstrappedUser(userData.uid, userData.email);
    setIsAuthLoading(false);
  };

  const handleSigningOutAction = async () => {
    try {
      if (!isFirebaseEnabled) {
        localStorage.removeItem("mk_chat_cached_user");
      }
      await handleSignOut();
      setUser(null);
      setProfile(null);
      setSessions([]);
      setCurrentSessionId(null);
      setMessages([]);
    } catch (err: any) {
      console.error("Sign-out failed:", err);
    }
  };

  // Workshop actions: Create Session
  const handleCreateNewSessionAction = async () => {
    if (!user) return;
    try {
      const session = await createChatSession(user.uid, "New Conversation");
      setSessions((prev) => [session, ...prev]);
      setCurrentSessionId(session.id);
    } catch (err: any) {
      console.error("Session creation failed", err);
    }
  };

  const handleDeleteSessionAction = async (chatId: string) => {
    if (!user) return;
    try {
      await deleteChatSession(chatId, user.uid);
      const filtered = sessions.filter((s) => s.id !== chatId);
      setSessions(filtered);

      if (currentSessionId === chatId) {
        setCurrentSessionId(filtered.length > 0 ? filtered[0].id : null);
      }
    } catch (err: any) {
      console.error("Session deletion failed", err);
    }
  };

  const handleRenameSessionAction = async (chatId: string, title: string) => {
    if (!user) return;
    try {
      await updateChatSessionTitle(chatId, title, user.uid);
      setSessions((prev) =>
        prev.map((s) => (s.id === chatId ? { ...s, title, updatedAt: new Date().toISOString() } : s))
      );
    } catch (err: any) {
      console.error("Rename failed", err);
    }
  };

  const handleUpgradeTierAction = async () => {
    if (!user) return;
    try {
      await updateUserProfile(user.uid, { isPremium: true });
      setProfile((prev) => (prev ? { ...prev, isPremium: true, updatedAt: new Date().toISOString() } : null));
    } catch (err: any) {
      console.error("Upgrade action failed", err);
    }
  };

  // Chat message submission matching Proxy API endpoints
  const handleSendMessageAction = async (text: string) => {
    if (!user || !currentSessionId) return;

    // 1. Immediately post the user message visually and save it
    const tempUserMsgId = `temp_user_msg_${Date.now()}`;
    const userMsg: ChatMessage = {
      id: tempUserMsgId,
      role: "user",
      content: text,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsModelLoading(true);

    try {
      const savedUserMsg = await addChatMessage(
        currentSessionId,
        "user",
        text,
        user.uid
      );

      // Swap temp message with cloud message to sync exact IDs
      setMessages((prev) => prev.map((m) => (m.id === tempUserMsgId ? savedUserMsg : m)));

      // 2. Prepare context map to pass over to Gemini through the server
      const currentHistory = [...messages, savedUserMsg];
      
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: currentHistory.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          systemInstruction:
            "You are Muhammad Kumail MK Chatbot, configured with a slate-style premium UI. Respect the user, use clean professional replies, write solid logic blocks, and use structured markdown when answering code/lists.",
          isPremium: profile?.isPremium || false,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json();
        throw new Error(errorJson.error || "A connection anomaly occurred inside the AI pipeline.");
      }

      const { text: modelResponseText, groundingChunks, searchQueries } = await response.json();

      // 3. Save the returned Model response
      const savedModelMsg = await addChatMessage(
        currentSessionId,
        "model",
        modelResponseText,
        user.uid,
        groundingChunks,
        searchQueries
      );

      setMessages((prev) => [...prev, savedModelMsg]);
    } catch (err: any) {
      console.error("Gemini response fetching failure:", err);
      // Append an AI fallback error card explaining what failed
      const errorAIResponse: ChatMessage = {
        id: `error_ai_${Date.now()}`,
        role: "model",
        content: `❌ **Failed to retrieve answer from Muhammad Kumail MK Chatbot.**\n\n*Error details:* ${
          err.message || "Is your Gemini API key configured inside Settings > Secrets?"
        }\n\nMake sure your environment has a valid key associated to process requests.`,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errorAIResponse]);
    } finally {
      setIsModelLoading(false);
    }
  };

  const selectedSession = sessions.find((s) => s.id === currentSessionId) || null;

  // Render Full Page Load Loader
  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-neutral-950 text-neutral-300">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500 mb-4" />
        <span className="font-mono text-xs tracking-widest text-neutral-500 uppercase">
          SECURE TRANSCRIPT GATEWAY LOADING
        </span>
      </div>
    );
  }

  // Render Login state gateway
  if (!user) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} onSignInActionDone={handleGoogleSignIn} />;
  }

  return (
    <div className="min-h-screen bg-neutral-950 font-sans text-neutral-200 flex overflow-hidden">
      {/* Policy warning header if terms block */}
      {sysError && (
        <div className="fixed top-4 left-4 right-4 z-50 p-4 bg-amber-950/90 border border-amber-500/30 rounded-xl flex items-center gap-3 shadow-2xl text-amber-200 max-w-xl mx-auto backdrop-blur-md">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <div className="text-xs">
            <span className="font-semibold block mb-0.5">Firestore System Event Log</span>
            {sysError}
          </div>
          <button onClick={() => setSysError(null)} className="ml-auto text-amber-400 hover:text-white font-bold p-1">
            ✕
          </button>
        </div>
      )}

      {/* Sidebar history selector */}
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onCreateSession={handleCreateNewSessionAction}
        onDeleteSession={handleDeleteSessionAction}
        onRenameSession={handleRenameSessionAction}
        profile={profile}
        onOpenPricing={() => setIsPricingOpen(true)}
        userEmail={user.email}
        userDisplayName={user.displayName}
        onSignOut={handleSigningOutAction}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
      />

      {/* Main Content Area */}
      <ChatPlayground
        currentSession={selectedSession}
        messages={messages}
        onSendMessage={handleSendMessageAction}
        isModelLoading={isModelLoading}
        profile={profile}
        onOpenPricing={() => setIsPricingOpen(true)}
        onToggleSidebarMobile={() => setMobileSidebarOpen(true)}
      />

      {/* Upgrading detailed checklist */}
      <PricingModal
        isOpen={isPricingOpen}
        onClose={() => setIsPricingOpen(false)}
        onUpgradeComplete={handleUpgradeTierAction}
        profile={profile}
      />
    </div>
  );
}
