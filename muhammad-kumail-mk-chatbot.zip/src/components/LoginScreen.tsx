import { useState } from "react";
import { motion } from "motion/react";
import { LogIn, Sparkles, AlertCircle, Cpu, ShieldCheck } from "lucide-react";
import { isFirebaseEnabled } from "../firebase";

interface LoginScreenProps {
  onLoginSuccess: (userData: { uid: string; email: string; displayName: string }) => void;
  onSignInActionDone: () => Promise<{ uid: string; email: string; displayName: string }>;
}

export default function LoginScreen({ onLoginSuccess, onSignInActionDone }: LoginScreenProps) {
  const [loading, setLoading] = useState(false);
  const [errorString, setErrorString] = useState<string | null>(null);

  const handleSignIn = async () => {
    setLoading(true);
    setErrorString(null);
    try {
      const user = await onSignInActionDone();
      onLoginSuccess(user);
    } catch (err: any) {
      console.error("Sign-in issue:", err);
      setErrorString(
        err.message ||
        "Login was interrupted. If you just initialized Firebase, ensure pops are enabled or terms are registered."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-12 bg-neutral-950 font-sans text-neutral-100 relative overflow-hidden">
      {/* Decorative Gradients */}
      <div className="absolute top-1/4 -left-12 w-96 h-96 rounded-full bg-violet-600/10 blur-[100px]" />
      <div className="absolute bottom-1/4 -right-12 w-96 h-96 rounded-full bg-blue-600/10 blur-[100px]" />

      {/* Left Column: Visual Showcase Panel */}
      <div className="hidden lg:flex lg:col-span-7 bg-neutral-900/40 relative flex-col justify-between border-r border-neutral-900 px-12 py-16">
        <div className="flex items-center gap-2">
          <Cpu className="w-6 h-6 text-violet-500" />
          <span className="font-mono text-sm tracking-wider font-semibold text-neutral-400">MK COMPUTE SYSTEMS</span>
        </div>

        <div className="space-y-6 max-w-lg my-auto">
          <div className="inline-flex items-center gap-1 px-3 py-1 bg-violet-500/10 text-violet-400 rounded-full text-xs font-semibold border border-violet-500/20">
            <Sparkles className="w-3 h-3 text-violet-400 animate-pulse" />
            Gemini Chatbot Experience
          </div>
          <h1 className="text-4xl xl:text-5xl font-bold tracking-tight text-white leading-[1.15]">
            Muhammad Kumail <br />
            <span className="bg-gradient-to-r from-violet-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
              MK Chatbot
            </span>
          </h1>
          <p className="text-neutral-400 text-base leading-relaxed">
            Experience advanced AI reasoning paired with localized chat logs and dynamic real-time Google Search Grounding.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-neutral-500 font-mono">
          <ShieldCheck className="w-4 h-4 text-violet-500/60" /> SECURITY VERIFIED BY FIREBASE AUTH
        </div>
      </div>

      {/* Right Column: Interaction Form */}
      <div className="col-span-12 lg:col-span-5 flex flex-col justify-center px-6 sm:px-12 py-16 relative">
        <div className="max-w-md w-full mx-auto space-y-8">
          {/* Mobile Display Title */}
          <div className="lg:hidden text-center space-y-2">
            <h1 className="text-2xl font-bold text-white">Muhammad Kumail MK Chatbot</h1>
            <p className="text-sm text-neutral-400">Premium dark UI Gemini client</p>
          </div>

          <div className="bg-neutral-900/40 rounded-2xl border border-neutral-800 p-8 shadow-xl">
            <div className="mb-6 space-y-2">
              <h2 className="text-xl font-semibold text-white">Welcome Back</h2>
              <p className="text-xs text-neutral-400">
                Authenticate with Google Auth to instantly load your saved chat sessions and subscriptions.
              </p>
            </div>

            {errorString && (
              <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-lg text-xs text-red-200 flex gap-2 mb-4">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorString}</span>
              </div>
            )}

            <button
              id="google-signin-btn"
              onClick={handleSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 bg-white hover:bg-neutral-100 text-neutral-900 font-medium py-3 px-4 rounded-xl transition duration-200 outline-none select-none disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer active:scale-[0.99]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.77c-.98.66-2.23 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>

            {!isFirebaseEnabled && (
              <div className="mt-4 p-3 bg-violet-950/20 border border-violet-500/20 rounded-lg text-[11px] text-violet-400">
                <span className="font-semibold block mb-0.5">💡 Preview Environment Sandbox Enabled</span>
                Firebase setup is pending Terms of Service approval. Click standard Google Login above to immediately experience optimized simulated sessions and user flows!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
