import { motion, AnimatePresence } from "motion/react";
import { X, Check, Star, Zap, Shield, Sparkles } from "lucide-react";
import { UserProfile } from "../types";

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgradeComplete: () => void;
  profile: UserProfile | null;
}

export default function PricingModal({ isOpen, onClose, onUpgradeComplete, profile }: PricingModalProps) {
  if (!isOpen) return null;

  const handleUpgrade = () => {
    onUpgradeComplete();
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          id="pricing-dialog"
          className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl"
        >
          {/* Background Ambient Glow */}
          <div className="absolute top-0 left-1/2 -z-10 h-40 w-80 -translate-x-1/2 rounded-full bg-violet-600/10 blur-[60px]" />

          {/* Close Trigger */}
          <button
            id="close-pricing-btn"
            onClick={onClose}
            className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-100 transition-colors p-1 hover:bg-neutral-900 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-violet-500/10 text-violet-400 rounded-full text-xs font-semibold mb-3 border border-violet-500/20">
              <Sparkles className="w-3.5 h-3.5" />
              Upgrade to Pro Experience
            </div>
            <h2 className="text-2xl font-semibold tracking-tight text-white mb-2">
              Unlock Advanced Reasoning
            </h2>
            <p className="text-sm text-neutral-400">
              Elevate your daily workflows with Muhammad Kumail MK Chatbot's pro tools.
            </p>
          </div>

          {/* Core Pricing Card */}
          <div className="border border-violet-500/30 bg-neutral-900/50 rounded-xl p-5 mb-6 relative">
            {profile?.isPremium && (
              <span className="absolute -top-3 right-4 bg-violet-600 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider text-white">
                Active Tier
              </span>
            )}
            
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-sm text-violet-400 font-semibold tracking-wide uppercase">
                  MK Pro Monthly
                </span>
                <div className="flex items-baseline mt-1">
                  <span className="text-4xl font-extrabold text-white">$20</span>
                  <span className="text-neutral-400 ml-1 text-sm">/month</span>
                </div>
              </div>
              <div className="bg-violet-950/50 border border-violet-500/20 text-violet-400 px-3 py-1.5 rounded-lg text-xs font-mono">
                Cancel any time
              </div>
            </div>

            {/* Features layout list */}
            <div className="space-y-3.5 my-5 text-sm text-neutral-300">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-full bg-violet-500/20 p-0.5 text-violet-400">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block font-medium">Real-time Web Search Grounding</strong>
                  <span className="text-neutral-400 text-xs">Instantly search the live internet for sports outcomes, breaking news, or references.</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-full bg-violet-500/20 p-0.5 text-violet-400">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block font-medium">Powered by Gemini 3.5 Flash</strong>
                  <span className="text-neutral-400 text-xs">Access lightning-fast coding assistance, creative writing, and data extraction.</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-full bg-violet-500/20 p-0.5 text-violet-400">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block font-medium">Unlimited Chat Transcripts</strong>
                  <span className="text-neutral-400 text-xs">Save every conversation securely on Firestore with zero rate limits or token locks.</span>
                </div>
              </div>
            </div>

            {/* Call to Action Button */}
            {profile?.isPremium ? (
              <div className="w-full text-center py-3 bg-neutral-800 text-neutral-400 font-semibold rounded-xl text-sm cursor-not-allowed">
                You are on Premium Tier
              </div>
            ) : (
              <button
                id="upgrade-action-btn"
                onClick={handleUpgrade}
                className="w-full py-3 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl text-sm transition-all duration-200 shadow-md shadow-violet-600/20 flex items-center justify-center gap-2 group active:scale-[0.98]"
              >
                <Zap className="w-4 h-4 fill-white group-hover:scale-110 transition-transform" />
                Simulate Payment & Upgrade
              </button>
            )}

            <div className="text-center text-[11px] text-neutral-500 mt-3 flex items-center justify-center gap-4">
              <span className="flex items-center gap-1">
                <Shield className="w-3 h-3" /> Secure checkout
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Star className="w-3 h-3 text-amber-500" /> Developer Demo Ready
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
