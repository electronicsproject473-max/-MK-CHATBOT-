import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, Search, Compass, ExternalLink, Globe, Brain, Terminal, ChevronRight, AlertCircle } from "lucide-react";
import { ChatMessage, ChatSession, UserProfile } from "../types";

interface ChatPlaygroundProps {
  currentSession: ChatSession | null;
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isModelLoading: boolean;
  profile: UserProfile | null;
  onOpenPricing: () => void;
  onToggleSidebarMobile: () => void;
}

// Resilient Custom Markdown and Code Highlighter component built in pure React
function FormatAIResponse({ text }: { text: string }) {
  if (!text) return null;

  // Split text into lines to compile blocks cleanly
  const paragraphs = text.split("\n\n");

  return (
    <div className="space-y-4 text-sm leading-relaxed text-zinc-200">
      {paragraphs.map((para, pIdx) => {
        const trimmed = para.trim();
        if (!trimmed) return null;

        // 1. Code Block Matching (```lang ... ```)
        if (trimmed.startsWith("```")) {
          const lines = trimmed.split("\n");
          const firstLine = lines[0];
          const lang = firstLine.replace("```", "").trim() || "typescript";
          const code = lines.slice(1, lines[lines.length - 1].startsWith("```") ? -1 : undefined).join("\n");

          return (
            <div key={pIdx} className="my-3 rounded-lg overflow-hidden border border-white/5 bg-black/40 font-mono text-[13px]">
              <div className="bg-[#18181b] px-4 py-2 border-b border-white/5 flex justify-between items-center select-none text-zinc-400">
                <span className="text-[10px] text-zinc-400 font-mono tracking-wider uppercase flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-indigo-400" /> {lang}
                </span>
                <span className="text-[9px] text-white/30 font-mono">DEVELOPER ENGINE</span>
              </div>
              <pre className="p-4 overflow-x-auto text-indigo-300 whitespace-pre scrollbar-thin">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // 2. Unordered Bullet Point list matching
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
          const items = trimmed.split("\n");
          return (
            <ul key={pIdx} className="list-disc pl-5 space-y-2 my-2 text-zinc-300">
              {items.map((item, iIdx) => {
                const cleanItem = item.replace(/^[-*]\s+/, "");
                return <li key={iIdx}>{renderInlineFormats(cleanItem)}</li>;
              })}
            </ul>
          );
        }

        // 3. Numbered list matching
        if (/^\d+\.\s+/.test(trimmed)) {
          const items = trimmed.split("\n");
          return (
            <ol key={pIdx} className="list-decimal pl-5 space-y-2 my-2 text-zinc-300">
              {items.map((item, iIdx) => {
                const cleanItem = item.replace(/^\d+\.\s+/, "");
                return <li key={iIdx}>{renderInlineFormats(cleanItem)}</li>;
              })}
            </ol>
          );
        }

        // 4. Headers Matching
        if (trimmed.startsWith("## ")) {
          return (
            <h3 key={pIdx} className="text-base font-bold text-white mt-4 first:mt-0 tracking-tight flex items-center gap-2">
              <ChevronRight className="w-4 h-4 text-indigo-400 shrink-0" />
              {trimmed.replace("## ", "")}
            </h3>
          );
        }
        if (trimmed.startsWith("### ")) {
          return (
            <h4 key={pIdx} className="text-sm font-bold text-white mt-3 first:mt-0">
              {trimmed.replace("### ", "")}
            </h4>
          );
        }

        // Standard Paragraph with inline formats
        return (
          <p key={pIdx} className="text-zinc-300 leading-relaxed font-sans text-sm md:text-[14.5px]">
            {renderInlineFormats(para)}
          </p>
        );
      })}
    </div>
  );
}

// Inline Formatter for Bold (**), Italics (*), and Code (` inline `)
function renderInlineFormats(chunkText: string) {
  // Regex to look for **
  const parts = chunkText.split(/(\*\*.*?\*\*|`.*?`)/g);
  return parts.map((part, idx) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={idx} className="font-semibold text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={idx} className="bg-white/5 px-1.5 py-0.5 rounded text-[11.5px] font-mono text-indigo-300 font-medium border border-white/5">
          {part.slice(1, -1)}
        </code>
      );
    }
    return part;
  });
}

export default function ChatPlayground({
  currentSession,
  messages,
  onSendMessage,
  isModelLoading,
  profile,
  onOpenPricing,
  onToggleSidebarMobile,
}: ChatPlaygroundProps) {
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isModelLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText("");
  };

  const handleSuggestClick = (prompt: string) => {
    onSendMessage(prompt);
  };

  const suggestions = [
    {
      title: "Write TypeScript Logic",
      desc: "Implement a reliable generic interface with mock states.",
      prompt: "Show me a TypeScript code sample for a full-stack generic state manager using interface generics.",
      icon: Terminal,
      color: "text-violet-400 bg-violet-500/10",
    },
    {
      title: "Quantum Computation",
      desc: "Explain it to a beginner with space-age analogies.",
      prompt: "Write a simple and visual explanation of Quantum Superposition and Quantum Computing for an average reader.",
      icon: Compass,
      color: "text-blue-400 bg-blue-500/10",
    },
    {
      title: "Real-time Live News",
      desc: "Requires Pro grounding search features.",
      prompt: "Who won the last Super Bowl? List the detailed final score and game highlight notes.",
      icon: Globe,
      color: "text-amber-400 bg-amber-500/10",
      requiresPremium: true,
    },
  ];

  return (
    <div className="flex-1 flex flex-col bg-neutral-950 font-sans relative h-screen overflow-hidden">
      {/* Top Header Controls */}
      <header className="h-14 border-b border-neutral-900 px-4 md:px-6 flex items-center justify-between bg-neutral-950/80 backdrop-blur shrink-0 z-10">
        <div className="flex items-center gap-3">
          <button
            id="mobile-sidebar-toggle-btn"
            onClick={onToggleSidebarMobile}
            className="p-2 -ml-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-lg lg:hidden cursor-pointer"
          >
            <Compass className="w-5 h-5" />
          </button>
          {currentSession ? (
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-white truncate max-w-[200px] sm:max-w-xs md:max-w-md">
                {currentSession.title}
              </h2>
              <span className="text-[10px] text-neutral-500 block font-mono">
                {messages.length} MESSAGE TRANSCRIPTS SAVED
              </span>
            </div>
          ) : (
            <div>
              <h2 className="text-sm font-semibold text-white">Google Gemini Playground</h2>
              <span className="text-[10px] text-neutral-500 block font-mono">SELECT A WORKSPACE TO BEGIN</span>
            </div>
          )}
        </div>

        {/* Premium Level Indicators */}
        <div className="flex items-center gap-2">
          {profile?.isPremium ? (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 text-amber-500 border border-amber-500/30 rounded-full text-xs font-semibold select-none">
              <Globe className="w-3.5 h-3.5 fill-amber-500/10" />
              <span>Real-time Search</span>
            </div>
          ) : (
            <button
              id="header-upgrade-trigger"
              onClick={onOpenPricing}
              className="inline-flex items-center gap-1.2 py-1 px-3 bg-violet-600 hover:bg-violet-500 text-white rounded-full text-xs font-semibold select-none shadow-md shadow-violet-600/10 cursor-pointer active:scale-95 transition-all"
            >
              <Sparkles className="w-3 h-3 fill-white" />
              Upgrade to Pro
            </button>
          )}
        </div>
      </header>

      {/* Primary Conversation Stream Viewport */}
      <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 space-y-6">
        {!currentSession || messages.length === 0 ? (
          // Welcome Dashboard State
          <div className="max-w-2xl mx-auto py-10 space-y-12">
            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center font-bold text-white shadow-xl shadow-violet-500/20 text-lg mb-4 animate-pulse">
                MK
              </div>
              <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-none">
                Muhammad Kumail <span className="bg-gradient-to-r from-violet-400 to-blue-400 bg-clip-text text-transparent">MK Chatbot</span>
              </h1>
              <p className="text-neutral-400 text-sm md:text-base max-w-md mx-auto leading-relaxed">
                Connect directly with Google Gemini API models, structured under a gorgeous midnight premium dark UI.
              </p>
            </div>

            {/* suggestion panels */}
            <div className="space-y-4">
              <h3 className="text-xs font-semibold font-mono tracking-wider text-neutral-500 uppercase">
                RECOMMENDATION LABS
              </h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {suggestions.map((s, idx) => {
                  const Icon = s.icon;
                  return (
                    <div
                      key={idx}
                      id={`suggest-card-${idx}`}
                      onClick={() => handleSuggestClick(s.prompt)}
                      className="group p-4 rounded-xl border border-neutral-900 bg-neutral-900/30 hover:bg-neutral-900/60 hover:border-neutral-800 cursor-pointer transition-all duration-200 flex flex-col gap-3 min-h-[140px]"
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${s.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-semibold text-xs text-white block mb-1 group-hover:text-violet-400 transition-colors">
                          {s.title}
                        </span>
                        <span className="text-[11px] text-neutral-400 line-clamp-3">
                          {s.desc}
                        </span>
                      </div>
                      {s.requiresPremium && !profile?.isPremium && (
                        <span className="mt-auto inline-flex items-center text-[9px] text-amber-500 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded w-max tracking-wide">
                          PRO PLAN
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          // Conversation Bubble Stack
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.map((m) => {
              const isUser = m.role === "user";
              return (
                <div
                  key={m.id}
                  id={`chat-bubble-${m.id}`}
                  className={`flex gap-4 ${isUser ? "justify-end" : "justify-start"}`}
                >
                  {/* Sender Avatar badge */}
                  {!isUser && (
                    <div className="w-8 h-8 rounded-lg bg-violet-600/15 border border-violet-500/10 shrink-0 flex items-center justify-center font-bold text-violet-400 text-xs select-none">
                      AI
                    </div>
                  )}

                  <div className={`max-w-[85%] rounded-2xl p-4 border shadow-sm ${
                    isUser
                      ? "bg-violet-600/15 border-violet-500/20 text-neutral-200 rounded-tr-none px-5"
                      : "bg-neutral-900/40 border-neutral-900 text-neutral-300 rounded-tl-none"
                  }`}>
                    {/* Render Chat Text Content */}
                    {isUser ? (
                      <p className="text-sm md:text-[14.5px] leading-relaxed whitespace-pre-wrap">{m.content}</p>
                    ) : (
                      <FormatAIResponse text={m.content} />
                    )}

                    {/* Grounding and search queries if available (Premium level only) */}
                    {!isUser && m.searchQueries && m.searchQueries.length > 0 && (
                      <div className="mt-3.5 pt-3 border-t border-neutral-800/80 flex flex-wrap items-center gap-2">
                        <span className="text-[10px] text-neutral-500 font-mono tracking-wider flex items-center gap-1 select-none">
                          <Search className="w-3 h-3 text-amber-500" /> SEARCH GROUNDING LOGIC:
                        </span>
                        {m.searchQueries.map((query, qIdx) => (
                          <span
                            key={qIdx}
                            className="text-[10px] px-2 py-0.5 rounded bg-neutral-850 border border-neutral-800 text-amber-500 font-mono"
                          >
                            "{query}"
                          </span>
                        ))}
                      </div>
                    )}

                    {!isUser && m.groundingChunks && m.groundingChunks.length > 0 && (
                      <div className="mt-2 space-y-1.5">
                        <span className="text-[10px] text-neutral-500 font-mono tracking-wider flex items-center gap-1 select-none">
                          <Compass className="w-3 h-3 text-emerald-400" /> VERIFIED WEB CITATIONS:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {m.groundingChunks.map((chunk, cIdx) => (
                            <a
                              key={cIdx}
                              href={chunk.uri}
                              target="_blank"
                              referrerPolicy="no-referrer"
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-500/5 hover:bg-emerald-500/15 text-emerald-400 text-[10.5px] font-medium border border-emerald-500/15 transition-colors"
                            >
                              <ExternalLink className="w-2.5 h-2.5" />
                              <span className="truncate max-w-[140px]">{chunk.title}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Generating response typing state loader */}
            {isModelLoading && (
              <div id="ai-typing-indicator" className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-violet-600/10 border border-violet-500/10 shrink-0 flex items-center justify-center text-violet-400">
                  <Brain className="w-4 h-4 animate-bounce" />
                </div>
                <div className="max-w-[80%] rounded-2xl p-4 bg-neutral-900/20 border border-neutral-900 rounded-tl-none space-y-3.5 flex-1 shadow-sm">
                  {/* Google Search Status placeholder if in premium search mode */}
                  {profile?.isPremium && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-500 font-mono tracking-wider select-none animate-pulse">
                      <Globe className="w-3.5 h-3.5 fill-amber-500/15" /> ACTIVATE LIVE INTERNET SEARCH PIPELINE...
                    </div>
                  )}
                  {/* Skeleton lines with CSS animations */}
                  <div className="space-y-2 font-sans">
                    <div className="h-3 w-[90%] bg-neutral-800/60 rounded animate-pulse" />
                    <div className="h-3 w-[75%] bg-neutral-800/60 rounded animate-pulse" />
                    <div className="h-3 w-[45%] bg-neutral-800/60 rounded animate-pulse" />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Message Composition Bar */}
      <footer className="p-4 bg-neutral-950 border-t border-neutral-900 shrink-0 z-10">
        <div className="max-w-3xl mx-auto relative">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              id="chat-message-input"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              disabled={isModelLoading || !currentSession}
              placeholder={
                currentSession
                  ? profile?.isPremium
                    ? "Ask Kumail MK Chatbot anything (Live Web search is active!)"
                    : "Ask Kumail MK Chatbot anything..."
                  : "Please select or create a chat session in the sidebar to begin..."
              }
              className="flex-1 min-h-[46px] bg-neutral-900 text-neutral-100 rounded-xl px-4 py-2 text-sm border border-neutral-800 focus:border-violet-500/50 focus:outline-none transition group-hover:border-neutral-700 disabled:opacity-45 disabled:cursor-not-allowed text-stone-100 outline-none"
            />
            <button
              id="send-message-btn"
              type="submit"
              disabled={!inputText.trim() || isModelLoading || !currentSession}
              className="p-3 bg-violet-600 hover:bg-violet-500 disabled:bg-neutral-900/60 text-white disabled:text-neutral-600 rounded-xl transition duration-150 flex items-center justify-center shrink-0 cursor-pointer disabled:cursor-not-allowed select-none active:scale-[0.98]"
            >
              <Send className="w-4 h-4 rotate-0" />
            </button>
          </form>

          {/* Premium search status footnote */}
          {currentSession && (
            <div className="text-[10px] text-neutral-500 text-center mt-2 font-mono">
              {profile?.isPremium ? (
                <span className="text-amber-500/80 flex items-center justify-center gap-1">
                  👑 PREMIUM PRO MEMBERSHIP ACTIVE • DOUBLE CONTEXT WINDOWS & DYNAMIC GOOGLE SEARCH GROUNDING CHANNELS READY
                </span>
              ) : (
                <span className="hover:text-violet-400 cursor-pointer transition-colors" onClick={onOpenPricing}>
                  💡 Upgrade to Pro to unlock Live Google Search integration for real-time news and references.
                </span>
              )}
            </div>
          )}
        </div>
      </footer>
    </div>
  );
}
