import React, { useState } from "react";
import { Plus, MessageSquare, Trash2, Edit2, Check, X, LogOut, Sparkles, Crown, Zap, Menu } from "lucide-react";
import { ChatSession, UserProfile } from "../types";

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onCreateSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  profile: UserProfile | null;
  onOpenPricing: () => void;
  userEmail: string;
  userDisplayName: string;
  onSignOut: () => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export default function Sidebar({
  sessions,
  currentSessionId,
  onSelectSession,
  onCreateSession,
  onDeleteSession,
  onRenameSession,
  profile,
  onOpenPricing,
  userEmail,
  userDisplayName,
  onSignOut,
  mobileOpen,
  setMobileOpen,
}: SidebarProps) {
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const handleStartRename = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveRename = (session: ChatSession, e: React.MouseEvent | React.FormEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (editTitle.trim() && editTitle.trim() !== session.title) {
      onRenameSession(session.id, editTitle.trim());
    }
    setEditingSessionId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(null);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          id="mobile-sidebar-backdrop"
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed inset-y-0 left-0 z-40 w-72 border-r border-white/5 bg-[#020202] flex flex-col justify-between transition-transform duration-300 lg:static lg:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Top: Branding & New Chat CTA */}
        <div className="p-4 border-b border-white/5 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center font-bold text-white shadow-md shadow-indigo-500/20 text-sm">
                MK
              </div>
              <div>
                <span className="font-semibold block text-sm text-white leading-tight">Kumail MK Chatbot</span>
                <span className="text-[10px] text-white/40 font-mono tracking-wider">PREMIUM SYSTEM</span>
              </div>
            </div>
            <button
              id="close-mobile-sidebar-btn"
              onClick={() => setMobileOpen(false)}
              className="lg:hidden text-white/60 hover:text-white p-1 hover:bg-white/5 rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <button
            id="new-chat-btn"
            onClick={() => {
              onCreateSession();
              setMobileOpen(false);
            }}
            className="w-full h-10 border border-white/10 hover:border-white/20 bg-white/5 hover:bg-white/10 text-sm font-medium text-white rounded-lg flex items-center justify-center gap-2 transition-all duration-200 group active:scale-[0.99] cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4 text-white/60 group-hover:scale-110 transition-transform" />
            New Chat
          </button>
        </div>

        {/* Middle: Chat History Transcripts */}
        <div className="flex-1 overflow-y-auto px-2 py-4 space-y-1">
          <h3 className="px-3 text-[11px] font-bold text-white/40 font-mono tracking-widest uppercase mb-2">
            CONVERSATION HISTORY
          </h3>

          {sessions.length === 0 ? (
            <div className="text-center py-8 px-4 text-xs text-white/30">
              No chat history yet. Start speaking with Kumail MK Chatbot!
            </div>
          ) : (
            sessions.map((session) => {
              const isActive = session.id === currentSessionId;
              const isEditing = session.id === editingSessionId;

              return (
                <div
                  key={session.id}
                  id={`session-item-${session.id}`}
                  onClick={() => {
                    onSelectSession(session.id);
                    setMobileOpen(false);
                  }}
                  className={`group relative rounded-lg px-3 py-2 flex items-center gap-3 cursor-pointer text-sm transition-all duration-150 select-none ${
                    isActive
                      ? "bg-white/5 border border-white/10 text-white font-medium"
                      : "text-white/60 border border-transparent hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? "text-indigo-400" : "text-white/20"}`} />

                  {isEditing ? (
                    <form
                      onSubmit={(e) => handleSaveRename(session, e)}
                      className="flex-1 flex items-center gap-1.5 min-w-0"
                    >
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        autoFocus
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 bg-white/5 text-white rounded px-1.5 py-0.5 text-xs border border-white/20 focus:border-indigo-500/50 focus:outline-none min-w-0"
                      />
                      <button
                        type="button"
                        onClick={(e) => handleSaveRename(session, e)}
                        className="text-emerald-400 hover:text-emerald-300 p-0.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelRename}
                        className="text-red-400 hover:text-red-300 p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  ) : (
                    <span className="flex-1 truncate pr-16 text-xs">{session.title}</span>
                  )}

                  {/* Edit/Delete Commands (hidden until hover) */}
                  {!isEditing && (
                    <div className="absolute right-2 opacity-0 group-hover:opacity-100 flex items-center bg-black/40 rounded pl-1 gap-1 transition-all">
                      <button
                        onClick={(e) => handleStartRename(session, e)}
                        className="p-1 text-white/40 hover:text-white hover:bg-white/5 rounded transition-colors"
                        title="Rename Chat"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteSession(session.id);
                        }}
                        className="p-1 text-white/40 hover:text-red-400 hover:bg-red-950/20 rounded transition-colors"
                        title="Delete Chat"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Bottom: Upgrade Banner & User Profile Context */}
        <div className="p-4 border-t border-white/5 bg-[#020202] flex flex-col gap-4">
          {/* Pro / Premium Plan Presentation */}
          {profile?.isPremium ? (
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 flex items-center gap-3 select-none">
              <div className="w-9 h-9 min-w-[36px] rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20">
                <Crown className="w-5 h-5 fill-amber-400/10" />
              </div>
              <div className="min-w-0">
                <span className="font-bold text-xs text-amber-400 flex items-center gap-1">
                  MK PREMIUM PRO <Sparkles className="w-3 h-3 text-amber-400 fill-amber-400" />
                </span>
                <span className="text-[10px] text-white/50 block line-clamp-1">Live Google Search Grounding active</span>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-900/40 to-black border border-indigo-500/20">
              <div className="text-[11px] font-bold text-indigo-400 mb-1">PREMIUM PLAN</div>
              <p className="text-[11px] text-white/60 mb-3 leading-relaxed">Access Real-time Web Search Grounding & limitless conversational history.</p>
              <button
                id="sidebar-upgrade-cta"
                onClick={onOpenPricing}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-md shadow-lg shadow-indigo-900/20 transition-all cursor-pointer active:scale-95"
              >
                Upgrade to Premium
              </button>
            </div>
          )}

          {/* User profile identifier block */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-xs font-bold text-white shadow-inner shrink-0 select-none">
              {userDisplayName ? userDisplayName.slice(0, 2).toUpperCase() : "MK"}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-white truncate">
                {userDisplayName || "Muhammad Kumail"}
              </div>
              <div className="text-[10px] text-white/40 truncate">
                {userEmail || "kumail@example.com"}
              </div>
            </div>

            <button
              id="logout-action-btn"
              onClick={onSignOut}
              className="p-1 px-1.5 text-white/40 hover:text-red-400 hover:bg-white/5 rounded-md transition-colors cursor-pointer shrink-0"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
