import { initializeApp, getApp, getApps } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  orderBy,
  deleteDoc,
  writeBatch,
} from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";
import { UserProfile, ChatSession, ChatMessage, OperationType, FirestoreErrorInfo } from "./types";

// Determine if we should use true Firebase cloud services or the premium localStorage fallback
export const isFirebaseEnabled =
  firebaseConfig &&
  !firebaseConfig.isPlaceholder &&
  firebaseConfig.apiKey !== "PLACEHOLDER_API_KEY" &&
  firebaseConfig.projectId !== "placeholder-project";

let app: any = null;
export let db: any = null;
export let auth: any = null;

if (isFirebaseEnabled) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    auth = getAuth(app);
    console.log("Firebase is initialized with active Cloud Project:", firebaseConfig.projectId);
  } catch (error) {
    console.error("Failed to initialize active Firebase client SDK:", error);
  }
} else {
  console.log("Using Premium Client-Side Storage engines (Firebase is in placeholder state).");
}

// Strictly mandated safety error handling for Cloud Operations
function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Policy Alert: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to validate connection (as required by Firestore verification guidelines)
export async function validateConnection() {
  if (!isFirebaseEnabled) return;
  try {
    // Attempt standard server read test
    await getDoc(doc(db, "test", "connection"));
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.warn("Please check your Firebase configuration: Client appears offline.");
    }
  }
}

// ----------------------------------------------------
// DB OPERATORS: USER PROFILES
// ----------------------------------------------------

export async function fetchUserProfile(userId: string): Promise<UserProfile | null> {
  const path = `user_profiles/${userId}`;
  if (!isFirebaseEnabled) {
    const key = `mk_chat_profile_${userId}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      return JSON.parse(stored);
    }
    return null;
  }

  try {
    const userDoc = await getDoc(doc(db, "user_profiles", userId));
    if (userDoc.exists()) {
      return userDoc.data() as UserProfile;
    }
    return null;
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createUserProfile(userId: string, email: string): Promise<UserProfile> {
  const profile: UserProfile = {
    userId,
    email,
    isPremium: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const path = `user_profiles/${userId}`;
  if (!isFirebaseEnabled) {
    localStorage.setItem(`mk_chat_profile_${userId}`, JSON.stringify(profile));
    return profile;
  }

  try {
    await setDoc(doc(db, "user_profiles", userId), profile);
    return profile;
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<void> {
  const path = `user_profiles/${userId}`;
  if (!isFirebaseEnabled) {
    const existing = await fetchUserProfile(userId);
    if (existing) {
      const updated = { ...existing, ...updates, updatedAt: new Date().toISOString() };
      localStorage.setItem(`mk_chat_profile_${userId}`, JSON.stringify(updated));
    }
    return;
  }

  try {
    const ref = doc(db, "user_profiles", userId);
    const existing = await getDoc(ref);
    if (existing.exists()) {
      await setDoc(ref, {
        ...existing.data(),
        ...updates,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    }
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ----------------------------------------------------
// DB OPERATORS: CHAT SESSIONS
// ----------------------------------------------------

export async function fetchChatSessions(userId: string): Promise<ChatSession[]> {
  const path = "chats";
  if (!isFirebaseEnabled) {
    const sessionsKey = `mk_chat_sessions_${userId}`;
    const stored = localStorage.getItem(sessionsKey);
    return stored ? JSON.parse(stored) : [];
  }

  try {
    const q = query(
      collection(db, "chats"),
      where("userId", "==", userId),
      orderBy("updatedAt", "desc")
    );
    const snapshot = await getDocs(q);
    const list: ChatSession[] = [];
    snapshot.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as ChatSession);
    });
    return list;
  } catch (error) {
    return handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function createChatSession(userId: string, title: string): Promise<ChatSession> {
  const id = isFirebaseEnabled ? "" : `session_${Date.now()}`;
  const session: Omit<ChatSession, "id"> = {
    userId,
    title: title || "New Chat",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const path = "chats";
  if (!isFirebaseEnabled) {
    const sessions = await fetchChatSessions(userId);
    const newSession: ChatSession = { id, ...session };
    sessions.unshift(newSession);
    localStorage.setItem(`mk_chat_sessions_${userId}`, JSON.stringify(sessions));
    return newSession;
  }

  try {
    const docRef = await addDoc(collection(db, "chats"), session);
    return { id: docRef.id, ...session };
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateChatSessionTitle(chatId: string, title: string, userId: string): Promise<void> {
  const path = `chats/${chatId}`;
  if (!isFirebaseEnabled) {
    const sessions = await fetchChatSessions(userId);
    const idx = sessions.findIndex((s) => s.id === chatId);
    if (idx !== -1) {
      sessions[idx].title = title;
      sessions[idx].updatedAt = new Date().toISOString();
      localStorage.setItem(`mk_chat_sessions_${userId}`, JSON.stringify(sessions));
    }
    return;
  }

  try {
    await setDoc(doc(db, "chats", chatId), { title, updatedAt: new Date().toISOString() }, { merge: true });
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteChatSession(chatId: string, userId: string): Promise<void> {
  const path = `chats/${chatId}`;
  if (!isFirebaseEnabled) {
    const sessions = await fetchChatSessions(userId);
    const filtered = sessions.filter((s) => s.id !== chatId);
    localStorage.setItem(`mk_chat_sessions_${userId}`, JSON.stringify(filtered));
    localStorage.removeItem(`mk_chat_messages_${chatId}`);
    return;
  }

  try {
    // Delete documents in the messages subcollection first
    const messagesSnapshot = await getDocs(collection(db, "chats", chatId, "messages"));
    const batch = writeBatch(db);
    messagesSnapshot.forEach((d) => {
      batch.delete(doc(db, "chats", chatId, "messages", d.id));
    });
    batch.delete(doc(db, "chats", chatId));
    await batch.commit();
  } catch (error) {
    return handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ----------------------------------------------------
// DB OPERATORS: CHAT MESSAGES (SUBCOLLECTION)
// ----------------------------------------------------

export async function fetchChatMessages(chatId: string): Promise<ChatMessage[]> {
  const path = `chats/${chatId}/messages`;
  if (!isFirebaseEnabled) {
    const stored = localStorage.getItem(`mk_chat_messages_${chatId}`);
    return stored ? JSON.parse(stored) : [];
  }

  try {
    const q = query(
      collection(db, "chats", chatId, "messages"),
      orderBy("createdAt", "asc")
    );
    const snapshot = await getDocs(q);
    const list: ChatMessage[] = [];
    snapshot.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as ChatMessage);
    });
    return list;
  } catch (error) {
    return handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function addChatMessage(
  chatId: string,
  role: "user" | "model" | "system",
  content: string,
  userId: string,
  groundingChunks?: { title: string; uri: string }[],
  searchQueries?: string[]
): Promise<ChatMessage> {
  const messageData: Omit<ChatMessage, "id"> = {
    role,
    content,
    createdAt: new Date().toISOString(),
    ...(groundingChunks && { groundingChunks }),
    ...(searchQueries && { searchQueries }),
  };

  const path = `chats/${chatId}/messages`;
  if (!isFirebaseEnabled) {
    const msgs = await fetchChatMessages(chatId);
    const newMsg: ChatMessage = { id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`, ...messageData };
    msgs.push(newMsg);
    localStorage.setItem(`mk_chat_messages_${chatId}`, JSON.stringify(msgs));

    // Update timestamps on the chat session listing
    const sessions = await fetchChatSessions(userId);
    const idx = sessions.findIndex((s) => s.id === chatId);
    if (idx !== -1) {
      sessions[idx].updatedAt = new Date().toISOString();
      localStorage.setItem(`mk_chat_sessions_${userId}`, JSON.stringify(sessions));
    }
    return newMsg;
  }

  try {
    // Add message
    const docRef = await addDoc(collection(db, "chats", chatId, "messages"), messageData);
    
    // Touch chat session updatedAt
    await setDoc(doc(db, "chats", chatId), { updatedAt: new Date().toISOString() }, { merge: true });

    return { id: docRef.id, ...messageData };
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// ----------------------------------------------------
// POP-UP AUTH HELPERS (GOOGLE LOGIN)
// ----------------------------------------------------

export const googleProvider = isFirebaseEnabled ? new GoogleAuthProvider() : null;

export async function handleGoogleSignIn(): Promise<{ uid: string; email: string; displayName: string }> {
  if (!isFirebaseEnabled) {
    // Simulate high-contrast Google Popup flow beautifully
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          uid: "local_user_kumail",
          email: "electronicsproject473@gmail.com",
          displayName: "Muhammad Kumail",
        });
      }, 800);
    });
  }

  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    return {
      uid: user.uid,
      email: user.email || "",
      displayName: user.displayName || "User",
    };
  } catch (error) {
    console.error("Firebase auth dialog error:", error);
    throw error;
  }
}

export async function handleSignOut(): Promise<void> {
  if (!isFirebaseEnabled) {
    return Promise.resolve();
  }
  return signOut(auth);
}

export function subscribeToAuth(callback: (user: FirebaseUser | null) => void) {
  if (!isFirebaseEnabled) {
    // Return mock unsubscriber
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}
